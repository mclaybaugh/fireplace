<?php
?>
<footer class="site-footer">
	
</footer><!-- #colophon -->

<?php wp_footer(); ?>

</body>
</html>
